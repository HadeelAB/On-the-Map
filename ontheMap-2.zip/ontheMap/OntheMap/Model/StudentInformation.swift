//
//  StudentInformation.swift
//  ontheMap
//
//  Created by هَديل  on 06/05/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import Foundation

struct StudentInformation: Codable {
    var createdAt: String?
    var firstName: String?
    var lastName: String?
    var latitude: Double?
    var longitude: Double?
    var mapString: String?
    var mediaURL: String?
    var objectId: String?
    var uniqueKey: String?
    var updatedAt: String?
}

extension StudentInformation {
    init(mapString: String, mediaURL: String, uniqueKey: String) {
        self.mapString = mapString
        self.mediaURL = mediaURL
        self.uniqueKey = uniqueKey
    }
}





