//
//  NeededInfo.swift
//  ontheMap
//
//  Created by هَديل  on 22/05/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import Foundation
struct NeededInfo {
    var key: String?
    var firstName: String?
    var lastName: String?
}
