//
//  StudentLocations.swift
//  ontheMap
//
//  Created by هَديل  on 07/05/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import Foundation
