//
//  LoginViewController.swift
//  ontheMap
//
//  Created by هَديل  on 04/05/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var LoginButton: UIButton!
    @IBOutlet weak var signupButton: UIButton!
    
    struct LoginData: Codable {
        var account: Account
    }
    
    struct Account: Codable {
        var registered: Bool
        var key: Int
    }

    struct UserData: Codable {
        var email: String
        var password: String
    }

    @IBAction func Login(_ sender: Any) {
        let ai = showActivityIndicator()
        API.Login(email: emailTextField.text!, password: passwordTextField.text!) { (errorMessage) in
            DispatchQueue.main.async {
                ai.stopAnimating()
                if errorMessage != nil{
                    self.showAlert(title: "Login faild!", message: errorMessage!)
                    return
                }
                else{

                    self.performSegue(withIdentifier: "TabBarSegue", sender: nil)
                }
            }
        }
    }
    
    @IBAction func signUp(_ sender: Any) {
        if let URL = URL(string: "https://auth.udacity.com/sign-up"){
            UIApplication.shared.open(URL, options: [:], completionHandler: nil)
        }
        else {
            self.showAlert(title: "Sorry", message: "Can't disspay the sign Up page ")
        }
    }
}
