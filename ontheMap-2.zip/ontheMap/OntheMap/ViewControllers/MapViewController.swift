//
//  MapViewController.swift
//  ontheMap
//
//  Created by هَديل  on 06/05/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: SharedViewController ,MKMapViewDelegate {

    @IBOutlet weak var MapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        MapView.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        API.getStudentsLocation() { (studentsLocations, error) in
            DispatchQueue.main.async {

                if error != nil {
                    super.showAlert(title: "Erorr performing request", message: "There was an error performing your request")
                }
                
                var annotations = [MKPointAnnotation] ()
                guard let locationsArray = studentsLocations else {
                    super.showAlert(title: "Erorr loading locations", message: "There was an error loading locations")
                    return
                }
                
                for locationStruct in locationsArray {
                    let long = CLLocationDegrees (locationStruct.longitude ?? 0)
                    let lat = CLLocationDegrees (locationStruct.latitude ?? 0)
                    let coords = CLLocationCoordinate2D (latitude: lat, longitude: long)
                    let mediaURL = locationStruct.mediaURL ?? " "
                    let firstName = locationStruct.firstName ?? " "
                    let lastName = locationStruct.lastName ?? " "
                    let annotation = MKPointAnnotation()
                    annotation.coordinate = coords
                    annotation.title = "\(firstName) \(lastName)"
                    annotation.subtitle = mediaURL
                    annotations.append (annotation)
                }
                self.MapView.addAnnotations (annotations)
            }
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        
        return pinView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        if control == view.rightCalloutAccessoryView {
            let app = UIApplication.shared
            if let toOpen = view.annotation?.subtitle! {
                app.open(URL(string: toOpen)!, options: [:], completionHandler: nil)
            }
        }
    }
    
    @IBAction func refresh(_ sender: Any) {
        super.refreshLocationsTapped(self)
    }
    
    @IBAction func addPin(_ sender: Any) {
        super.addLocationTapped(self)
    }
    @IBAction func logout(_ sender: Any) {
        super.logoutTapped(self)
    }
    
}
