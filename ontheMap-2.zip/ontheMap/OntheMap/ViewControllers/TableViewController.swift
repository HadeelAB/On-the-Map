//
//  TableViewController.swift
//  ontheMap
//
//  Created by هَديل  on 06/05/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import UIKit

class TableViewController: SharedViewController, UITableViewDelegate, UITableViewDataSource {
   
    @IBOutlet weak var tableView: UITableView!
    var studentsLocations: [StudentInformation] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
  
    override func viewWillAppear(_ animated: Bool) {
        self.callAPI()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return studentsLocations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let currentStudent = studentsLocations[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        cell?.textLabel?.text = "\(currentStudent.firstName ?? "") \(currentStudent.lastName ?? "")"
        cell?.detailTextLabel?.text = currentStudent.mediaURL
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let currentStudent = studentsLocations[indexPath.row]    
        if let URL = URL(string: currentStudent.mediaURL! ) {
            UIApplication.shared.open(URL, options: [:], completionHandler: nil)
        }
    }
    
    func callAPI(){
        API.getStudentsLocation { (studentsLocations, error) in
            DispatchQueue.main.async {
                if error != nil {
                    self.showAlert(title: "Erorr performing request", message: "There was an error performing your request")
                    return
                }
            
                guard let locationsArray = studentsLocations else {
                    self.showAlert(title: "Erorr loading locations", message: "There was an error loading locations")
                    return
                }
                self.studentsLocations = locationsArray
                self.tableView.reloadData()
            }
        }
    }
    
    @IBAction func refresh(_ sender: Any) {
       self.callAPI()
    }
    
    @IBAction func addPin(_ sender: Any) {
        super.addLocationTapped(self)
    }
    
    @IBAction func logout(_ sender: Any) {
        super.logoutTapped(self)
    }
}
