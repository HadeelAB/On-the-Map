//
//  ConfirmLocationViewController.swift
//  ontheMap
//
//  Created by هَديل  on 21/05/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import UIKit
import MapKit

class ConfirmLocationViewController: UIViewController {

    var location: StudentInformation?
    @IBOutlet weak var map: MKMapView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print("in con")
        self.pinCreater()
    }
    
    func pinCreater() {
        guard let location = location else {
            self.showAlert(title: "error in  map loading", message: "can not load the map")
            return
        }
        
        let long = CLLocationDegrees (location.longitude ?? 0)
        let lat = CLLocationDegrees (location.latitude ?? 0)
        let coords = CLLocationCoordinate2D (latitude: lat, longitude: long)
        let first = location.firstName ?? " "
        let last = location.lastName ?? " "
        let mediaURL = location.mediaURL ?? " "
        let annotation = MKPointAnnotation()
        annotation.coordinate = coords
        annotation.title = "\(first) \(last)"
        annotation.subtitle = mediaURL
        self.map.addAnnotation(annotation)
    }
    
    @IBAction func finishButton(_ sender: Any) {
        API.postLocation(location!) { (error) in
            DispatchQueue.main.async {
                if error != nil {
                    self.showAlert(title: "post location faild", message: "can not post your location")
                }
                else {
                    self.navigationController?.popToRootViewController(animated: true)
                }
            }
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        var pinView = map.dequeueReusableAnnotationView(withIdentifier: "myPin" ) as? MKPinAnnotationView
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "pin")
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        return pinView
    }
}
