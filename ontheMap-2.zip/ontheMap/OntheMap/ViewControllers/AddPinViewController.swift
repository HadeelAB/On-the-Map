//
//  AddPinViewController.swift
//  ontheMap
//
//  Created by هَديل  on 14/05/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import UIKit
import CoreLocation

class AddPinViewController: UIViewController {

    @IBOutlet weak var location: UITextField!
    @IBOutlet weak var mediaURL: UITextField!
    @IBOutlet weak var findLocation: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func cancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func findLocation(_ sender: Any) {
        guard let location = location.text,
            let mediaLink = mediaURL.text,
            location != "", mediaLink != "" else {
                self.showAlert(title: "Missing information", message: "Please fill both fields and try again")
                return
        }
        let studentLocation = StudentInformation(mapString: location, mediaURL: mediaLink, uniqueKey: AppDelegate.userInfo.key!)
        coordinates(studentLocation)
    }
    
    
    func coordinates(_ studentLocation: StudentInformation) {
        let ai = showActivityIndicator()
        CLGeocoder().geocodeAddressString(studentLocation.mapString!) { (arr, error) in
            DispatchQueue.main.async {
                ai.stopAnimating()
                guard let firstLocation = arr?.first?.location else {
                    self.showAlert(title: "can not find location!", message: "please enter valid location")
                    return
                }
                var location = studentLocation
                location.latitude = firstLocation.coordinate.latitude
                location.longitude = firstLocation.coordinate.longitude
            
                let VC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmLocationViewController") as! ConfirmLocationViewController
                VC.location = location
                self.navigationController?.pushViewController(VC, animated: true)
            }
        }
    }
}
