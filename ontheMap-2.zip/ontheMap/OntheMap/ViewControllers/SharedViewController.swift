//
//  SharedViewController.swift
//  ontheMap
//
//  Created by هَديل  on 07/05/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import UIKit

class SharedViewController: UIViewController {
    
    var StudentLocation: [StudentInformation] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func addLocationTapped(_ sender: Any) {
        let navController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddLocationNavigationController") as! UINavigationController
        
        present(navController, animated: true, completion: nil)
    }
    
    func refreshLocationsTapped(_ sender: Any) {
        print("refreshLocationsTapped method")
        loadStudentLocations()
    }
    
    func logoutTapped(_ sender: Any) {
         print("logoutTapped method")
        API.Logout { (messege) in
            DispatchQueue.main.async {
                if messege != nil {
                    print("logout inside if")
                    self.showAlert(title: "Logout Faild", message: messege!)
                }
                else {
                    print("logout inside else")
                    let alert = UIAlertController(title: "Logout", message: "Are you sure you want to logout?", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Logout", style: UIAlertAction.Style.default, handler: { (action) in
                        //self.performSegue(withIdentifier: "LogoutSegue", sender: nil)
                        self.dismiss(animated: false, completion: nil)
                        print("logout done")
                    }))
                    alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { (action) in
                        alert.dismiss(animated: true, completion: nil)
                        print("Cancel logout")
                    }))
                    
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    func loadStudentLocations() {
        API.getStudentsLocation { (data, error) in
            guard let data = data else {
                self.showAlert(title: "Error", message: "No internet connection found")
                return
            }
            guard data.count > 0 else {
                self.showAlert(title: "Error", message: "No pins found")
                return
            }
            self.StudentLocation = data
        }
    }
}



extension UIViewController : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        return true
    }
}

extension UIViewController {
    func showActivityIndicator() -> UIActivityIndicatorView {
        let activityIndicator = UIActivityIndicatorView(style: .white)
        self.view.addSubview(activityIndicator)
        self.view.bringSubviewToFront(activityIndicator)
        activityIndicator.hidesWhenStopped = true
        activityIndicator.center = self.view.center
        activityIndicator.startAnimating()
        return activityIndicator
    }
    
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let action = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
    }
    
}



