//
//  ViewController.swift
//  ontheMap
//
//  Created by هَديل  on 03/05/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

