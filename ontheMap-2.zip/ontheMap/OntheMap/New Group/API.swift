//
//  API.swift
//  ontheMap
//
//  Created by هَديل  on 09/05/1440 AH.
//  Copyright © 1440 Hadeel. All rights reserved.
//

import Foundation
import UIKit

class API {

    static var sessionId: String?
    
    static func Login(email: String, password: String, complation: @escaping (String?)->Void) {
        
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let email = email
        let password = password
        var errorMessage: String?
        request.httpBody = "{\"udacity\": {\"username\": \"\(email)\", \"password\": \"\(password)\"}}".data(using: .utf8)
        //print(String(data: request.httpBody!, encoding: .utf8))
        
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            
            if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                if statusCode >= 200  && statusCode < 300 {
                    let range = Range(5..<data!.count)
                    let newData = data?.subdata(in: range)
                    if let object = try? JSONSerialization.jsonObject(with: newData!, options: []), let dict = object as? [String:Any], let sessionDict = dict["session"] as? [String: Any], let accountDict = dict["account"] as? [String: Any]  {
                        AppDelegate.userInfo.key = accountDict["key"] as! String
                        AppDelegate.userInfo.firstName = ""
                        AppDelegate.userInfo.lastName = ""
                        self.sessionId = sessionDict["id"] as? String
                        
                    } else { errorMessage = "Couldn't parse response" }
                } else { errorMessage = "incorrect email or password" }
            } else { errorMessage = "Check internet connection" }
            DispatchQueue.main.async {
                complation(errorMessage)
            }
        }
        task.resume()
    }
    
    static func getStudentsLocation(completion: @escaping ([StudentInformation]?, Error?) -> ()){
        
        var request = URLRequest(url: URL(string: "https://parse.udacity.com/parse/classes/StudentLocation?limit=100&order=-updatedAt")!)
        request.addValue("QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr", forHTTPHeaderField: "X-Parse-Application-Id")
        request.addValue("QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY", forHTTPHeaderField: "X-Parse-REST-API-Key")
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil {
                completion (nil,error)
                return
            }
            if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                if statusCode >= 200 && statusCode < 300 {
                    let json = try? JSONSerialization.jsonObject(with: data!, options: [])
                    let dict = json as? [String:Any]
                    let results = dict!["results"] as? [[String:Any]]
                    guard let array = results else { return }
                        let dataObject = try! JSONSerialization.data(withJSONObject: array, options: .prettyPrinted)
                        let studentsLocations = try! JSONDecoder().decode([StudentInformation].self, from: dataObject)
                        completion (studentsLocations, nil)
                }
            }
        }
        task.resume()
    }
    
    static func getUeserInfo(completion: @escaping (Error?)->Void){
        guard let url = URL(string: "https://onthemap-api.udacity.com/v1/users/3903878747\(AppDelegate.userInfo.key)") else {
            return
        }
        let request = URLRequest(url: url)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil {
                completion(error)
                return
            }
        
            let range = Range(5..<data!.count)
            let newData = data?.subdata(in: range)
            let json = try? JSONSerialization.jsonObject(with: newData!, options: [])
            let dict = json as? [String:Any]
            
            

        }
        task.resume()
    }
    
    static func postLocation(_ location: StudentInformation, completion: @escaping (Error?)->Void) {
        var request = URLRequest(url: URL(string: "https://parse.udacity.com/parse/classes/StudentLocation")!)
        request.httpMethod = "POST"
        request.addValue("QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr", forHTTPHeaderField: "X-Parse-Application-Id")
        request.addValue("QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY", forHTTPHeaderField: "X-Parse-REST-API-Key")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let json = "{\"uniqueKey\": \"\(AppDelegate.userInfo.key ?? "")\", \"firstName\": \"Hadeel\", \"lastName\": \"AB\",\"mapString\": \"\(location.mapString ?? "")\", \"mediaURL\": \"\(location.mediaURL ?? "")\", \"latitude\": \(location.latitude ?? 0.0), \"longitude\": \(location.longitude ?? 0.0)}"
        request.httpBody = json.data(using: .utf8)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if (error != nil) {
                completion(error)
            } else {
                completion(nil)
            }
        }
        task.resume()
    }
    
    static func Logout(completion: @escaping (String?)->Void){
        guard let url = URL(string: "https://onthemap-api.udacity.com/v1/session") else {
            completion("url is invalid")
            return
        }
        var request = URLRequest(url: url)
        //request.httpMethod = "DELETE"
        var xsrfCookie: HTTPCookie? = nil
        let sharedCookieStorage = HTTPCookieStorage.shared
        for cookie in sharedCookieStorage.cookies! {
            if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie }
        }
        if let xsrfCookie = xsrfCookie {
            request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil {
                return
            }
            let range = Range(5..<data!.count)
            let newData = data?.subdata(in: range) /* subset response data! */
            print(String(data: newData!, encoding: .utf8)!)
            DispatchQueue.main.async {
                completion(nil)
            }
        }
        task.resume()
    }

}
